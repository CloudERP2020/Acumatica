﻿// *** Code customized by InfoSourcing Inc for Acumatica Hackathon Project
// *** Validates lead address with USPS API web services and returns validated address
// *** Visit http://www.Info-Sourcing.com for any questions related to this project

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_IS_IS200020 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}