// *** Code customized by InfoSourcing Inc for Acumatica Hackathon Project
// *** Validates lead address with USPS API web services and returns validated address
// *** Visit http://www.Info-Sourcing.com for any questions related to this project

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using PX.Common;
using PX.Objects.AR;
using PX.Objects.CR.MassProcess;
using PX.Objects.CS;
using PX.Objects.GL;
using PX.Data;
using PX.Objects.IN;
using PX.SM;
using PX.Objects;
using PX.Objects.CR;
using System.Net;

namespace USPSAddressValidation
{
  
  public class LeadMaint_Extension:PXGraphExtension<LeadMaint>
  {
      private const string ProductionUrl = "http://production.shippingapis.com/ShippingAPI.dll";
      private const string TestingUrl = "http://testing.shippingapis.com/ShippingAPITest.dll";
      private WebClient web;

      public PXSelect<AddressTable> addresstable;
      // Load USPSConfig table to fetch configuration values
      public PXSelect<USPSConfig> uspsconfig;

      protected virtual IEnumerable AddressTable()
      {
          List<AddressTable> list = new List<AddressTable>();
         
          return list;
      }


    
    #region Action
    public PXFilter<AddressTable> addressinfo;
    public PXAction<Contact> verifyaddress;
    [PXUIField(DisplayName = "Verify Address", MapEnableRights = PXCacheRights.Select, MapViewRights = PXCacheRights.Select)]
    [PXLookupButton]
    
      // Call VerifyAddress method to validate, load values from config and query USPS
      public virtual IEnumerable verifyAddress(PXAdapter adapter)
    {
        string productionurl = string.Empty;
        string testurl = string.Empty;
        bool testmode = false;
        string username = string.Empty;
        foreach(USPSConfig config in uspsconfig.Select())
        {
            productionurl = config.ProductionUrl;
            testurl = config.TestUrl;
            testmode = (bool)config.TestMode;
            username = config.UserName;
        }

        addressinfo.Cache.Clear();
        AddressTable oTable = new AddressTable();
        int iCount = addressinfo.Select().Count;
        if (iCount <= 0)
            addressinfo.Insert(oTable);

        // Build the XML string with Lead address value to query
        try
        {
            Address contactAddress = (Base.AddressCurrent.View.Cache.Current as Address);
            addressinfo.Current.EnteredAddress1 = contactAddress.AddressLine1;
            addressinfo.Current.EnteredAddress2 = contactAddress.AddressLine2;
            addressinfo.Current.EnteredCity = contactAddress.City;
            addressinfo.Current.EnteredState = contactAddress.State;
            addressinfo.Current.EnteredZip = contactAddress.PostalCode;
            addressinfo.Current.EnteredCountry = contactAddress.CountryID;
            web = new WebClient();
          
            // Build the URL to submit with address values and choose to use test or production URL
            string validateUrl = (testmode) ? testurl : productionurl + "?API=Verify&XML=<AddressValidateRequest USERID=\"{0}\"><Address ID=\"{1}\"><Address1>{2}</Address1><Address2>{3}</Address2><City>{4}</City><State>{5}</State><Zip5>{6}</Zip5><Zip4>{7}</Zip4></Address></AddressValidateRequest>";
            validateUrl = string.Format(validateUrl, username, "", contactAddress.AddressLine1, contactAddress.AddressLine2, contactAddress.City, contactAddress.State, contactAddress.PostalCode, contactAddress.PostalCode);
            string addressxml = web.DownloadString(validateUrl);
            
            if (addressxml.Contains("<Error>"))
            {
                int idx1 = addressxml.IndexOf("<Description>") + 13;
                int idx2 = addressxml.IndexOf("</Description>");
                int l = addressxml.Length;
                string errDesc = addressxml.Substring(idx1, idx2 - idx1);
                addressinfo.Current.AdditionalInformation = errDesc;
                //throw new USPSManagerException(errDesc);
            }
            else
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(addressxml);

                System.Xml.XmlNode element = doc.SelectSingleNode("/AddressValidateResponse/Address/Address1");
                if (element != null)
                    addressinfo.Current.VerifiedAddress1 = element.InnerText;
                element = doc.SelectSingleNode("/AddressValidateResponse/Address/Address2");
                if (element != null)
                    addressinfo.Current.VerifiedAddress2 = element.InnerText;
                element = doc.SelectSingleNode("/AddressValidateResponse/Address/City");
                if (element != null)
                    addressinfo.Current.VerifiedCity = element.InnerText;
                element = doc.SelectSingleNode("/AddressValidateResponse/Address/State");
                if (element != null)
                    addressinfo.Current.VerifiedState = element.InnerText;
                element = doc.SelectSingleNode("/AddressValidateResponse/Address/Zip5");
                if (element != null)
                    addressinfo.Current.VerifiedZip = element.InnerText;
                addressinfo.Current.VerifiedCountry = contactAddress.CountryID;
                
            }
        }

        catch (Exception ex)
        {
            return adapter.Get();
        }
        
        // Show dialog window with validation results 
        if( addressinfo.AskExt() == WebDialogResult.OK)
        {

            (Base.AddressCurrent.View.Cache.Current as Address).AddressLine1 = addressinfo.Current.VerifiedAddress1;
            (Base.AddressCurrent.View.Cache.Current as Address).AddressLine2 = addressinfo.Current.VerifiedAddress2;
            (Base.AddressCurrent.View.Cache.Current as Address).City = addressinfo.Current.VerifiedCity;
            (Base.AddressCurrent.View.Cache.Current as Address).State = addressinfo.Current.VerifiedState;
            (Base.AddressCurrent.View.Cache.Current as Address).PostalCode = addressinfo.Current.VerifiedZip;
            //Base.AddressCurrent.View.Cache.IsDirty = true;
            Base.AddressCurrent.Cache.Update(Base.AddressCurrent.View.Cache.Current);
           // addressinfo.Cache.Clear();
            return adapter.Get();
        }
        return adapter.Get();
    }
    #endregion

    
  }
}