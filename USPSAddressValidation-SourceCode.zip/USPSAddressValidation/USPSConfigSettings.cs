// *** Code customized by InfoSourcing Inc for Acumatica Hackathon Project
// *** Validates lead address with USPS API web services and returns validated address
// *** Visit http://www.Info-Sourcing.com for any questions related to this project
using System;
using System.Collections;
using System.Collections.Generic;
using PX.SM;
using PX.Data;


namespace USPSAddressValidation
{
    public class USPSConfigSettings : PXGraph<USPSConfigSettings,USPSConfig>
    {
        public PXSelect<USPSConfig> uspsconfig;

    }
}