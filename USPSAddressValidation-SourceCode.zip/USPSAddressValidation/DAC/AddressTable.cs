﻿// *** Code customized by InfoSourcing Inc for Acumatica Hackathon Project
// *** Validates lead address with USPS API web services and returns validated address
// *** Visit http://www.Info-Sourcing.com for any questions related to this project

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PX.Data;
using PX.Objects;
namespace USPSAddressValidation
{
    [System.SerializableAttribute()]
    public class AddressTable : IBqlTable
    {
        #region Entered Address
        #region EnteredAddress1


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line One" )]

        public virtual string EnteredAddress1 { get; set; }
        public abstract class enteredAddress1 : IBqlField { }

        #endregion

        #region EnteredAddress2


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line Two")]

        public virtual string EnteredAddress2 { get; set; }
        public abstract class enteredAddress2 : IBqlField { }

        #endregion

        #region EnteredAddress3


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line Three")]

        public virtual string EnteredAddress3 { get; set; }
        public abstract class enteredAddress3 : IBqlField { }

        #endregion

        #region EnteredCity


        [PXString(512)]
        [PXUIField(DisplayName = "City")]

        public virtual string EnteredCity { get; set; }
        public abstract class enteredCity : IBqlField { }

        #endregion

        #region EnteredState


        [PXString(512)]
        [PXUIField(DisplayName = "State")]

        public virtual string EnteredState { get; set; }
        public abstract class enteredState : IBqlField { }

        #endregion

        #region EnteredZip


        [PXString(50)]
        [PXUIField(DisplayName = "Zip Code")]

        public virtual string EnteredZip { get; set; }
        public abstract class enteredZip : IBqlField { }

        #endregion

        #region EnteredCountry


        [PXString(100)]
        [PXUIField(DisplayName = "Country")]

        public virtual string EnteredCountry { get; set; }
        public abstract class enteredCountry : IBqlField { }

        #endregion
#endregion

        // 2 sets of storage of address old and new 
        #region Verified Address
        #region VerifiedAddress1


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line One")]

        public virtual string VerifiedAddress1 { get; set; }
        public abstract class verifiedAddress1 : IBqlField { }

        #endregion

        #region VerifiedAddress2


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line Two")]

        public virtual string VerifiedAddress2 { get; set; }
        public abstract class verifiedAddress2 : IBqlField { }

        #endregion
        #region VerifiedAddress3


        [PXString(512)]
        [PXUIField(DisplayName = "Address Line Three")]

        public virtual string VerifiedAddress3 { get; set; }
        public abstract class verifiedAddress3 : IBqlField { }

        #endregion

        #region VerifiedCity


        [PXString(512)]
        [PXUIField(DisplayName = "City")]

        public virtual string VerifiedCity { get; set; }
        public abstract class verifiedCity : IBqlField { }

        #endregion

        #region VerifiedState


        [PXString(512)]
        [PXUIField(DisplayName = "State")]

        public virtual string VerifiedState { get; set; }
        public abstract class verifiedState : IBqlField { }

        #endregion

        #region VerifiedZip


        [PXString(50)]
        [PXUIField(DisplayName = "Zip Code")]

        public virtual string VerifiedZip { get; set; }
        public abstract class verifiedZip : IBqlField { }

        #endregion

        #region VerifiedCountry


        [PXString(100)]
        [PXUIField(DisplayName = "Country")]

        public virtual string VerifiedCountry { get; set; }
        public abstract class verifiedCountry : IBqlField { }

        #endregion

        #region AdditionalInformation


        [PXString(2000)]
        [PXUIField(DisplayName = "Return Text")]

        public virtual string AdditionalInformation { get; set; }
        public abstract class additionalInformation : IBqlField { }

        #endregion

        #endregion

    }
}
