﻿// *** Code customized by InfoSourcing Inc for Acumatica Hackathon Project
// *** Validates lead address with USPS API web services and returns validated address
// *** Visit http://www.Info-Sourcing.com for any questions related to this project

﻿namespace USPSAddressValidation
{
	using System;
	using PX.Data;
	
	[System.SerializableAttribute()]
	public class USPSConfig : PX.Data.IBqlTable
	{
		#region ProductionUrl
		public abstract class productionUrl : PX.Data.IBqlField
		{
		}
		protected string _ProductionUrl;
		[PXDBString(512, IsUnicode = true)]
		[PXUIField(DisplayName = "ProductionUrl")]
		public virtual string ProductionUrl
		{
			get
			{
				return this._ProductionUrl;
			}
			set
			{
				this._ProductionUrl = value;
			}
		}
		#endregion
		#region TestUrl
		public abstract class testUrl : PX.Data.IBqlField
		{
		}
		protected string _TestUrl;
		[PXDBString(512, IsUnicode = true)]
		[PXUIField(DisplayName = "TestUrl")]
		public virtual string TestUrl
		{
			get
			{
				return this._TestUrl;
			}
			set
			{
				this._TestUrl = value;
			}
		}
		#endregion
		#region UserName
		public abstract class userName : PX.Data.IBqlField
		{
		}
		protected string _UserName;
		[PXDBString(100, IsUnicode = true)]
		[PXUIField(DisplayName = "UserName")]
		public virtual string UserName
		{
			get
			{
				return this._UserName;
			}
			set
			{
				this._UserName = value;
			}
		}
		#endregion
		#region TestMode
		public abstract class testMode : PX.Data.IBqlField
		{
		}
		protected bool? _TestMode;
		[PXDBBool()]
		[PXUIField(DisplayName = "TestMode")]
		public virtual bool? TestMode
		{
			get
			{
				return this._TestMode;
			}
			set
			{
				this._TestMode = value;
			}
		}
		#endregion
	}
}
